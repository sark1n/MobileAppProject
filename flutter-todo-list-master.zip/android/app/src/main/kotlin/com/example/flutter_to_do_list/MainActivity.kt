package com.example.flutter_to_do_list

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
